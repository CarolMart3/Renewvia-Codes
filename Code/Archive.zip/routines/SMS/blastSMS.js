// Send mass SMS's to customers with this code. Write the message in craftMessage() and pick the sites that this gets sent to in getCustomerListAllSites().
// This will send your message to the phone numbers registered on ThunderCloud.


exports.sendMessages = sendMessages;
var sparkmeter = require("../../apis/sparkmeter");
var sms = require("../../apis/telerivet");
var cldashes = "-------------------------------------------------------------------";




async function sendMessages(siteCodes, route) {

    // The message to be sent is written manually in the writeMessage function below,
    // but set the sites and sending routes in the event input object

    var customerList = await getCustomerList(siteCodes);
    var messageQueue = await makeQueue(customerList);
    var telerivetResponseList = await sms.multipleSmsQueueHandler(messageQueue, route);
    return telerivetResponseList;
}


function writeMessage(customerAccountNumber) {
    // This is where you write the message that can be sent out.
    return "Thank you for your patience. We are sorry for the delay. Please enjoy 6 hours of free power today as a token of our appreciation. Thanks for using Renewvia Energy.";
}






async function getCustomerList(siteCodes) {
    var customerListAllSites = [],
        i, siteCustomers;

    for (i in siteCodes) {
        siteCustomers = await sparkmeter.getCustomerList(siteCodes[i]);
        if (siteCustomers.error === null) {
            customerListAllSites = customerListAllSites.concat(siteCustomers.customers);
        }
    }

    return customerListAllSites;
}


function makeQueue(customerList) {
    var i, customerAccountNumber, phoneNumber;
    var messageQueue = [];

    for (i in customerList) {
        phoneNumber = customerList[i].phone_number;
        customerAccountNumber = customerList[i].code;

        if (customerList[i].meters[0].active === true && customerAccountNumber !== null) {
            messageQueue.push({ "content": writeMessage(customerAccountNumber), "to_number": phoneNumber });
        }
    }
    return messageQueue;
}
