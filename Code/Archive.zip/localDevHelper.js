/*
This code will never run on the remote server- it should only be called by the local environment (aka, on your computer, not on AWS).
The point of this is to have easy and local testing of all the major functions of the code. Here's how it works:

The testCases object provided below is a big object full of objects that simulate messages our server could receive.
This includes payments, SMS's, form inputs, and more. Each object is in exactly the same format as what could be sent from real sources.

The runTests() function below loops through those test cases one after another. If you read the outputs in the console log, you
can see if the tests were successful or not.

While these tests can be run with the production environment variables, it is better to use the local testing environment variables. That
way you can test anything you want and not worry about creating fake customers in our real database or on real ThunderClouds. So unless you're
intentionally testing with real ThunderCloud, real database, etc, make sure to set your environment variables correctly.

If you have any authentication errors, check tests.js. There is a note there about what is required to make SparkMeter's testing ThunderCloud happy.
Sometimes SparkMeter wipes it clean, and there are a few things you have to do to set it up to work with this testing.

One more thing- when you run the test cases, go to tests.js and add 1 to the counter variable. This makes sure all the test serial numbers and account numbers
aren't duplicates of previous test cases.
*/






var mainCode = require("./index");
var tests = require("./tests");
var testCases = tests.provideTestCases();


/*
Because this code runs when you hit "Go" on your computer, I wanted to make it easy to run all the test cases, but also to run other things.
So comment and uncomment things below as you please. Look at the bottom of these options for a place to write whatever code you want for testing
small things.
*/





// ---------------------------------------------------------
// Run all the test cases:
// ---------------------------------------------------------

// runTests(testCases);

// ---------------------------------------------------------
// ---------------------------------------------------------




// ---------------------------------------------------------
// Run a specific test case:
// ---------------------------------------------------------

// var response = runTest(testCases.testSMSs);
// var response = runSMStest(testCases.testSMSs); // Note this is separate because it runs in a different way

// ---------------------------------------------------------
// ---------------------------------------------------------




// ---------------------------------------------------------
// Run something that isn't in the test cases, but should be sent to the rest of the code
// ---------------------------------------------------------

var event = {
    MessageType: "checkForSMSSparkmeter",
};

var response = runTest(event);

// 23.2 and 29, for later

// ---------------------------------------------------------

// Examples 
// var event = {
//     MessageType: "Grid control",
//     DesiredState: "On",
//     SiteCode: "14"
// };

// var event = {
//     MessageType: "SMS blast",
//     SiteCodes: ["14"],
//     Route: "telerivetGatewayPhoneKenya"
// };


// var event = {
//     MessageType: "Tariff Change",
//     Action: "update",
//     SiteCode: "14",
//     SiteVoltage: 240,
//     LowBalanceThreshold: 10,
//     TariffResidential: 0.0000001,
//     TariffCommercial: 0.0000001,
//     TariffIndustrial: 0.0000001,
//     TariffReligious: 0.0000001
// };


// ---------------------------------------------------------
// ---------------------------------------------------------






// ---------------------------------------------------------
// Run something that doesn't talk to the rest of the code at all (it's a sandbox!)
// ---------------------------------------------------------


// var a = 3;


// ---------------------------------------------------------
// ---------------------------------------------------------








async function runTests(testCases) {

    var response;
    var i;
    var testCase;

    for (i in testCases) {

        testCase = testCases[i];
        console.log("---------------------------------------------------------------------------------------------------------");
        console.log("---------------------------------------------------------------------------------------------------------");
        console.log("---------------------------------------------------------------------------------------------------------");
        console.log("Running test: " + testCase.MessageType);
        console.log("---------------------------------------------------------------------------------------------------------");

        if (testCase.MessageType === "Telerivet") {
            response = await runSMStest(testCase);
        }
        else {
            response = await runTest(testCase);
        }

        console.log("Response is: " + JSON.stringify(response));
    }

}









async function runTest(input) {
    var response = await mainCode.handler(input);
    return response;
}




async function runSMStest(testSMSes) {
    var i;
    var event;
    var response;
    var SMSList = testSMSes.SMSList;

    console.log(SMSList);

    for (i in SMSList) {

        event = {
            MessageType: "Telerivet",
            message: SMSList[i],
            phoneNumber: "+14049367991"
        };

        response = await runTest(event);
        console.log("-----------------------------------------");
        console.log("Message was:\n" + SMSList[i] + "\n\nResponse was:\n" + response);
        console.log("-----------------------------------------");
    }

    return response;
}




